-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for motoringapp
DROP DATABASE IF EXISTS `motoringapp`;
CREATE DATABASE IF NOT EXISTS `motoringapp` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `motoringapp`;

-- Dumping structure for table motoringapp.car_brands
DROP TABLE IF EXISTS `car_brands`;
CREATE TABLE IF NOT EXISTS `car_brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pictures` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `car_brands_category_id_foreign` (`category_id`),
  CONSTRAINT `car_brands_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.car_brands: ~0 rows (approximately)
/*!40000 ALTER TABLE `car_brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `car_brands` ENABLE KEYS */;

-- Dumping structure for table motoringapp.categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.categories: ~0 rows (approximately)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `description`, `picture`, `created_at`, `updated_at`) VALUES
	(2, 'Cars', 'this is for normal cars', 'categories/gouJHLx3tYKpVHnJZavOs63JP4wvLSgN7ttxrcou.png', '2022-07-09 14:20:28', '2022-07-09 14:20:28'),
	(3, 'Convertibles', 'this are for convertibles or open roof cars', 'categories/DeiZXJuiI2jSnWjiNoycaXT1WSwH4Xot2rxKQzib.png', '2022-07-09 14:21:26', '2022-07-09 14:21:26'),
	(4, 'Mini Vans', 'This category is for Mini vans and buses', 'categories/UDScoOkaomt1HgqQ5sPvKAPdsfz9v72IWIbqFlXh.png', '2022-07-09 14:22:20', '2022-07-09 14:22:20'),
	(5, 'Pickup Trucks', 'this category is for pickup trucks', 'categories/L2j8uy34swmJU10IU9VUycTAbjQM0GNef3AdC682.png', '2022-07-09 14:24:42', '2022-07-09 14:24:42'),
	(6, 'Trucks', 'this are for heavy duty category vehincles', 'categories/hKZRO7s5n0WkGI2a8kCjoQKo8H50snxDa19TJeqh.png', '2022-07-09 14:26:36', '2022-07-09 14:26:36'),
	(7, 'Buses', 'this are for buses', 'categories/VwHJWFD8lI46IVjKs93ieocdlNs2xowhMlbvnVgY.png', '2022-07-09 14:27:44', '2022-07-09 14:27:44'),
	(8, 'Motorcycles', 'this are for motorcyles', 'categories/kziw61nMFLFeGKkG3w8GfprMk5EoRiMDVfXczhw4.png', '2022-07-09 14:28:31', '2022-07-09 14:28:31'),
	(9, 'Heavy Duty', 'this are for heavy duties vehincles like tractors ....', 'categories/6I1P0ewEyiI6xLJX2kta64ZNczluDa9YL488LRrc.png', '2022-07-09 14:29:26', '2022-07-09 14:29:26'),
	(10, 'Watercrafts', 'This are for water transportation vehincles', 'categories/YbKUHsm0cGtJeigTHhmpDlLu2FSN33St27EcYL8A.png', '2022-07-09 14:30:08', '2022-07-09 14:30:08');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Dumping structure for table motoringapp.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.failed_jobs: ~0 rows (approximately)
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Dumping structure for table motoringapp.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.migrations: ~8 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(11, '2022_07_06_224342_create_products_table', 2),
	(13, '2022_07_06_223755_create_categories_table', 3),
	(14, '2022_07_06_224252_create_car_brands_table', 3),
	(15, '2022_07_06_224840_create_services_table', 3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table motoringapp.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table motoringapp.personal_access_tokens
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.personal_access_tokens: ~0 rows (approximately)
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;

-- Dumping structure for table motoringapp.products
DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.products: ~0 rows (approximately)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Dumping structure for table motoringapp.services
DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `process` text COLLATE utf8mb4_unicode_ci,
  `assurance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `others` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.services: ~6 rows (approximately)
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` (`id`, `name`, `description`, `picture`, `process`, `assurance`, `others`, `created_at`, `updated_at`) VALUES
	(1, 'this is the service name', 'this is the app description', 'services/MlWXfvCTZI6EE9279IlTXayO4BzHKtJ16zT3LEkD.jpg', 'process1,process2,process3', 'this is the assurance', NULL, '2022-07-08 19:03:43', '2022-07-08 19:03:43'),
	(2, 'Another Service', 'second decription for the services created', 'services/Oqq5G6pSGJBlsYnr3vULaX3i9xdDj1xeOc1lP7V1.jpg', 'anotherPro1,anotherPro2,anotherPro3', 'assurance here now again', 'another addition updated content here', '2022-07-08 19:05:17', '2022-07-08 20:42:23'),
	(4, 'Engine Servicing', 'this is for car engine service', 'services/tXzZ62PDtlJC0CLfLD9ENWqNTuscspkUEEXCcOWM.jpg', '', '', '', '2022-07-08 19:13:06', '2022-07-08 19:13:06'),
	(5, 'Another service here', 'this is to check if the toast is showing', 'services/vDjPzdebqwpzwhM7JcAtGs5LZyGbj4MyJg5pW6TU.jpg', 'Process her,process there,process when, another process', 'assurance is here now so grab it very well', '', '2022-07-08 19:16:29', '2022-07-08 19:16:29'),
	(7, 'Service 7 here now', 'this is the service seven description', 'services/bBateRzmYTIctEJvIBlwHao134rawNCdy4cvtx9I.jpg', 'no process, no process seh', 'this is a good assurance for the application', 'another thing that you need to know about up', '2022-07-08 19:20:22', '2022-07-08 19:20:22');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;

-- Dumping structure for table motoringapp.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table motoringapp.users: ~0 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `type`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'MotoringApp Admin', 'admin@motoringapp.com', '2022-07-05 21:48:42', '$2y$10$Y5JlS94Cx9liSpk.Q3BdyeYRi3l7nld0tIBAWhBDRxV7uE.mZdMY2', 1, 'EpW7v76fmm', '2022-07-05 21:48:42', '2022-07-05 21:48:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
