<div>
    @livewire('inspection.engine-inspection',['product'=> $product])
    @livewire('inspection.electrical',['product'=> $product])
    @livewire('inspection.air-conditioning',['product'=> $product])
    @livewire('inspection.exterior',['product'=> $product])
    @livewire('inspection.interior',['product'=> $product])
    @livewire('inspection.test-drive',['product'=> $product])
    @livewire('inspection.suspension-and-steering',['product'=> $product])
    @livewire('inspection.transmission-and-clutch',['product'=> $product])
</div>
